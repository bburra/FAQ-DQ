package com.cg.util;


import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
	
	
	public static Connection createConnection(){
		Connection conn=null;
		try{
			InitialContext context = new InitialContext();
			DataSource ds = (DataSource)context.lookup("java:jboss/datasources/OracleDS");
			conn = ds.getConnection();
		}catch(NamingException e){
			e.printStackTrace();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return conn;
	}

}
