package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.AccountBean;
import com.cg.dto.TransactionBean;
import com.cg.exception.CustomerException;
import com.cg.util.DBUtil;

public class BankDAO implements IBankDAO {

	public BankDAO() {
		super();
	}
	
	

	@Override
	public int insertTransactionDetails(TransactionBean transBean) throws CustomerException {
		
				int status=0;
				Connection billConn=null;
				PreparedStatement psmtBill=null;
				String sql = new String("INSERT INTO transaction_details(transaction_id,transaction_description"
						+ "transaction_amount,transaction_date,account_number) VALUES(transaction_id_seq.nextval,'ATM Debit',?,sysdate,?)");
				try{
					billConn = DBUtil.createConnection();
					psmtBill = billConn.prepareStatement(sql);
					psmtBill.setDouble(1, transBean.getTransAmount());
					psmtBill.setString(2, transBean.getAccountNumber());
					
					status = psmtBill.executeUpdate();
					
				}catch(SQLException e){
					e.printStackTrace();
					throw new CustomerException("Cannot insert transaction details",e);
				}
				return status;
	}


	@Override
	public int isCustomerValid(String customerName) throws CustomerException {
		int status = 0;
		Connection billConn = null;
		ResultSet rs = null;
		try{
			billConn = DBUtil.createConnection();
			Statement stmt = billConn.createStatement();
			rs = stmt.executeQuery("SELECT count(customer_name) FROM account_details WHERE customer_name='"+customerName+"'");
			while(rs.next()){
				status = rs.getInt(1);
			}
		}catch(SQLException se){
			throw new CustomerException("Customer Name Not Found Exception for "+customerName,se);
		}
		return status;
	}


	@Override
	public ArrayList<AccountBean> showAccountDetails(String customerName)
			throws CustomerException {
		ArrayList<AccountBean> customerAccDetails = new ArrayList<AccountBean>();
		Connection billConn = null;
		AccountBean accBean=null;
		ResultSet rs = null;
		try{
			billConn = DBUtil.createConnection();
			Statement stmt = billConn.createStatement();
			rs = stmt.executeQuery("SELECT * FROM account_details WHERE customer_name='"+customerName+"'");
			while(rs.next()){
				accBean = new AccountBean();
				accBean.setAccountNumber(rs.getString(1));
				accBean.setCustomerName(rs.getString(2));
				accBean.setAccountType(rs.getString(3));
				accBean.setAccountLocation(rs.getString(4));
				accBean.setBalance(rs.getDouble(5));
				customerAccDetails.add(accBean);
			}
		}catch(SQLException se){
			throw new CustomerException("No Account Details available for the Customer- "+customerName,se);
		}
		return customerAccDetails;
	}


	
	
	

}
