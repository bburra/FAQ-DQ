package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.AccountBean;
import com.cg.dto.TransactionBean;
import com.cg.exception.CustomerException;
/*
 * TruckDao interface declaring all required operations 
 */
public interface IBankDAO {
	int insertTransactionDetails(TransactionBean transBean) throws CustomerException;
	public int isCustomerValid(String customerName) throws CustomerException;
	public ArrayList<AccountBean> showAccountDetails(String customerName) throws CustomerException;
}
