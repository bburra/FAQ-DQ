package com.cg.exception;

public class CustomerException extends Exception {

	/**
	 * This is the user-defined exception class
	 */
	private static final long serialVersionUID = 6350472084204605449L;

	public CustomerException() {
		
	}

	public CustomerException(String arg0) {
		super(arg0);
		
	}

	public CustomerException(Throwable arg0) {
		super(arg0);
		
	}

	public CustomerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public CustomerException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

}
